package sessionDB;

public class DBMS {

    private static final String connectionString = "jdbc:derby:data/sessiondb;create=true";
                                                                                                                        

    public DBMS(){
        System.out.println("NEW DATABASE CONNECTION");
    }



 }