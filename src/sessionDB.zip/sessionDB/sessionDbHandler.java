package sessionDB;
import java.sql.SQLException;
import java.util.ArrayList;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

public class sessionDbHandler implements sessionDbInterface {

    private DBMS dbms;

    public sessionDbHandler (DBMS dbms)throws SQLException{
        this.dbms = dbms;
        /*best check if the the database exists */
    }

	@Override
	public void assignRoom(String roomID, String sessionID) {
		// TODO Auto-generated method stub

	}

	@Override
	public void addSession() {
		// TODO Auto-generated method stub

	}

	@Override
	public ArrayList<Object> lectureView(String sessionID) {
		// TODO Auto-generated method stub
		System.out.println("LECTURE VIEW");
		return null;
	}
	
	public String importCourse(String courseToBeImported){
		String course = null;
		ArrayList<String> courses = myCampusStub();
		for(String increment: courses){
			if(increment==courseToBeImported){
				course = increment;
				
			}
			
			return increment;
		}
		System.out.print(course);
		return course;
		
	
}
	public void signUp(){
		
	}
	
	public void checkCompulsory(){
		
	}
	
	public 	ArrayList myCampusStub(){
		ArrayList<String> courses = new ArrayList();
		courses.add("Computing Science");
		courses.add("Sociology");
		courses.add("Exploring The Cosmos");
		return courses;
		
	}




}